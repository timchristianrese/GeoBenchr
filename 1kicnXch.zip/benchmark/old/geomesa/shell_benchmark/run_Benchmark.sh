#setup threaded benchmark for GeoMesa
#Read benchmark configuration from .yaml file
