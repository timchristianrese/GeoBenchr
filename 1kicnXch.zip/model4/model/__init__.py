# model/__init__.py
from .model import FlightLSTM