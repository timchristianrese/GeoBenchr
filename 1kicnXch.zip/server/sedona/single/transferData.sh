SSH_USER="XXXX-1"
IP="${1:-10.35.0.22}"
ssh $SSH_USER@$IP "mkdir -p /home/XXXX-1/data/aviation/; mkdir -p /home/XXXX-1/data/cycling; mkdir -p /home/XXXX-1/data/ais/; mkdir -p /home/XXXX-1/data/pedestrian/; mkdir -p /home/XXXX-1/data/movebank/; mkdir -p /home/XXXX-1/data/taxi/"

scp ../../data/processed/aviation/NRW_HIGH_01*.csv $SSH_USER@$IP:/home/XXXX-1/data/aviation/